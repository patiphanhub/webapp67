console.log("hello javascript")
console.log("hello bro")
document.getElementById("text").innerHTML="Patipan Jindamanee"
document.write("Hello Kub");
window.alert("Welcome My website Ahh web Page")